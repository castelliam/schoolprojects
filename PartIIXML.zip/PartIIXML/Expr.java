/*expr       ::= expr binOp expr
			|  INTEGER ; */

public class Expr {
	private Expr left;
	private Expr right;
	private PrimaryExpression val;
	private BinOp op;
	
	public Expr(Expr e1, Expr e2, BinOp op)
	{
		left = e1;
		right = e2;
		this.op = op;
	}
	
	public Expr(PrimaryExpression value) { val = value;}
	
	public String toXML() {
		String result = "<EXPR>\n";
		if (left != null) {
			result += op.toXML();
			result += "<left>\n";
			result += left.toXML();
			result += "</left>\n";
			result += "<right>\n";
			result += right.toXML();
			result += "</right>\n";
		}
		else {
			result += "<value>\n";
			result += val.toXML();
			result += "\n</value>\n";
		}
		result += "</EXPR>\n";
		return result;
	}
}

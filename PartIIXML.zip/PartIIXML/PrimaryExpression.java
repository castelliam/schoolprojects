public class PrimaryExpression {
	private int intLiteral; //IntegerLiteral
	private Expr right;
	private int val;
	private BinOp op;
	
	public PrimaryExpression(int i)
	{
		intLiteral = i;
	}

	/*public PrimaryExpression()
	{
	}

	public PrimaryExpression()
	{
	}

	public PrimaryExpression(expr )
	{
	}*/

	public String toXML() {
		String result = "<PrimaryExpression>\n";

		//if(intLiteral != null){
		result += intLiteral;
		//}
		result += "</PrimaryExpression>";
		return result;
	}
}